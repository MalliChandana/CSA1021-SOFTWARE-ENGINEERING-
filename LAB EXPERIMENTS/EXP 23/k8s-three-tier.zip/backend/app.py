import os, socket
import psycopg
from flask import Flask, jsonify, request

app = Flask(__name__)

def db():
    conn = psycopg.connect(host=os.environ["DB_HOST"], dbname=os.environ["POSTGRES_DB"],
                           user=os.environ["POSTGRES_USER"], password=os.environ["POSTGRES_PASSWORD"],
                           connect_timeout=3)
    conn.execute("CREATE TABLE IF NOT EXISTS items (id SERIAL PRIMARY KEY, name TEXT NOT NULL)")
    return conn

@app.get("/health")
def health():
    return "ok"

@app.route("/api/items", methods=["GET", "POST"])
def items():
    with db() as conn:
        if request.method == "POST":
            name = (request.get_json(silent=True) or {}).get("name", "").strip()
            if not name:
                return jsonify(error="name required"), 400
            conn.execute("INSERT INTO items (name) VALUES (%s)", (name,))
        rows = conn.execute("SELECT name FROM items ORDER BY id").fetchall()
    return jsonify(items=[r[0] for r in rows], served_by=socket.gethostname())
