from flask import Flask, redirect, render_template, request, url_for

app = Flask(__name__)
tasks = {}
next_id = 1

@app.get("/")
def index():
    return render_template("index.html", tasks=tasks)

@app.post("/add")
def add():
    global next_id
    title = request.form.get("title", "").strip()
    if title:
        tasks[next_id] = {"title": title, "done": False}
        next_id += 1
    return redirect(url_for("index"))

@app.post("/toggle/<int:task_id>")
def toggle(task_id):
    if task_id in tasks:
        tasks[task_id]["done"] = not tasks[task_id]["done"]
    return redirect(url_for("index"))

@app.post("/delete/<int:task_id>")
def delete(task_id):
    tasks.pop(task_id, None)
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
